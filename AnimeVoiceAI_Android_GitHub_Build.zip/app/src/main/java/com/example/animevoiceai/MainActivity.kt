package com.example.animevoiceai

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioAttributes
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioManager
import android.media.AudioDeviceInfo
import android.media.AudioTrack.MODE_STREAM
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import okhttp3.*
import okio.ByteString
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sampleRate = 24000
    private val channelIn = AudioFormat.CHANNEL_IN_MONO
    private val channelOut = AudioFormat.CHANNEL_OUT_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var socket: WebSocket? = null
    @Volatile private var running = false

    private lateinit var status: TextView
    private lateinit var character: Spinner
    private lateinit var serverUrl: EditText
    private lateinit var startButton: Button

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        val heading = TextView(this).apply {
            text = "ANIME VOICE AI"
            textSize = 26f
        }
        val intro = TextView(this).apply {
            text = "Protótipo de conversão de voz por IA"
            textSize = 15f
        }
        character = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("L — voz calma e analítica", "Light — voz firme e controlada",
                    "Ryuk — voz grave e rouca", "Gojo — voz descontraída",
                    "Itachi — voz serena", "Levi — voz fria e objetiva")
            )
        }
        serverUrl = EditText(this).apply {
            hint = "Servidor WebSocket (ex.: ws://192.168.0.10:8765)"
            setSingleLine(true)
            setText("ws://10.0.2.2:8765")
        }
        status = TextView(this).apply {
            text = "Status: desconectado"
            textSize = 14f
        }
        startButton = Button(this).apply {
            text = "Conectar e iniciar"
            setOnClickListener { if (!running) connectAndStart() else stopAudio() }
        }
        layout.addView(heading)
        layout.addView(intro)
        layout.addView(character)
        layout.addView(serverUrl)
        layout.addView(status)
        layout.addView(startButton)
        val note = TextView(this).apply {
            text = "\nEste protótipo envia áudio PCM para um servidor de conversão por IA e reproduz o áudio convertido. O servidor ainda precisa ser instalado e configurado."
            textSize = 13f
        }
        layout.addView(note)
        setContentView(layout)
    }

    private fun connectAndStart() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val request = Request.Builder().url(serverUrl.text.toString().trim()).build()
        status.text = "Status: conectando ao servidor…"
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread {
                    status.text = "Status: conectado — ${character.selectedItem}"
                    startButton.text = "Parar"
                }
                startCapture(webSocket)
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val data = bytes.toByteArray()
                player?.write(data, 0, data.size)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { status.text = "Falha: ${t.localizedMessage}" }
                stopAudio()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { status.text = "Status: conexão encerrada" }
                stopAudio()
            }
        })
    }

    private fun startCapture(ws: WebSocket) {
        val minIn = AudioRecord.getMinBufferSize(sampleRate, channelIn, encoding)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, channelOut, encoding)
        if (minIn <= 0 || minOut <= 0) {
            runOnUiThread { status.text = "Formato de áudio não suportado neste aparelho." }
            return
        }
        recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate, channelIn, encoding, minIn * 2
        )
        player = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setChannelMask(channelOut)
                .setEncoding(encoding).build())
            .setBufferSizeInBytes(minOut * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        recorder?.startRecording()
        player?.play()
        running = true
        thread(name = "voice-capture") {
            val buffer = ByteArray(960) // 20 ms at 24 kHz, mono, 16-bit
            while (running) {
                val count = recorder?.read(buffer, 0, buffer.size) ?: 0
                if (count > 0) ws.send(ByteString.of(*buffer.copyOf(count)))
            }
        }
    }

    private fun stopAudio() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        recorder = null
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        socket?.close(1000, "user stopped")
        socket = null
        runOnUiThread {
            startButton.text = "Conectar e iniciar"
            status.text = "Status: desconectado"
        }
    }

    override fun onDestroy() {
        stopAudio()
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}
