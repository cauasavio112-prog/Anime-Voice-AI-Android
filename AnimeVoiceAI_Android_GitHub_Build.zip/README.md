# Anime Voice AI — protótipo Android

Este é um **esqueleto inicial**, não um modificador de voz pronto. Ele implementa a interface Android, captura o microfone em PCM 16-bit mono a 24 kHz e envia blocos de áudio por WebSocket. O áudio binário recebido é reproduzido no aparelho.

## Abrir
1. Instale o Android Studio.
2. Abra a pasta `AnimeVoiceAI`.
3. Aguarde a sincronização do Gradle.
4. Execute em um celular Android e conceda permissão de microfone.
5. Configure o endereço WebSocket do servidor de conversão.

## Protocolo esperado do servidor
- Recebe mensagens binárias: PCM signed 16-bit little-endian, mono, 24.000 Hz.
- Retorna mensagens binárias no mesmo formato, já convertidas.
- A seleção do personagem ainda é apenas visual neste protótipo. A próxima etapa é enviar ao servidor um comando JSON com o preset selecionado e integrar um modelo de conversão de voz em tempo real.

## Importante sobre Roblox
O app reproduz o áudio convertido nos alto-falantes/fones, mas Android normalmente não permite que um app comum se registre como microfone virtual para outro app. Portanto, **este protótipo ainda não injeta a voz no Roblox**. A compatibilidade dependerá de uma rota de áudio externa suportada pelo aparelho ou de uma ponte em outro dispositivo. Não há garantia de que o Roblox aceite essa rota.

## Segurança e privacidade
O áudio do microfone é transmitido ao servidor configurado. Use somente um servidor seu ou confiável, com conexão protegida (WSS) quando sair da rede local. Avise outras pessoas quando estiver usando voz modificada. Os presets devem ser vozes sintéticas inspiradas em arquétipos/personagens, não clonagens não autorizadas de atores de voz.


## Gerar APK pelo celular usando GitHub Actions
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Abra a aba **Actions** do repositório.
3. Se aparecer uma mensagem pedindo autorização para workflows, permita.
4. Selecione **Build Android APK** e toque em **Run workflow** (ou envie um commit para `main`).
5. Quando a execução terminar com sucesso, abra a execução e baixe o artefato **AnimeVoiceAI-debug-apk**.
6. Extraia o ZIP do artefato e instale `app-debug.apk`.

O APK gerado é uma versão de teste (debug), não publicada na Play Store. O protótipo ainda precisa de um servidor de IA de conversão de voz e não transmite áudio diretamente ao microfone do Roblox.
